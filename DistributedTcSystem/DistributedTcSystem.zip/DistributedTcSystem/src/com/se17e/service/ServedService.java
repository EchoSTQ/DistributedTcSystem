package com.se17e.service;

public class ServedService {
	
	public static boolean init() {
		return true;
	}
}
