package com.se17e.dao.inter;

import com.se17e.bean.CacPara;

public interface AdminDaoInter {
	public boolean setCentralAcPara(CacPara cacPara);
}
